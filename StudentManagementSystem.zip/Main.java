import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentManagementSystem sms = new StudentManagementSystem();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== Student Management System =====");
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Remove Student");
            System.out.println("4. Search Student");
            System.out.println("5. Display All Students");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            while (!sc.hasNextInt()) {
                System.out.print("Invalid input. Enter a number: ");
                sc.next();
            }
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter roll number: ");
                    int roll = getValidInt(sc);
                    System.out.print("Enter grade: ");
                    String grade = sc.nextLine();
                    sms.addStudent(new Student(name, roll, grade));
                    System.out.println("Student added.");
                    break;

                case 2:
                    System.out.print("Enter roll number to edit: ");
                    int rollToEdit = getValidInt(sc);
                    Student existing = sms.searchStudent(rollToEdit);
                    if (existing != null) {
                        System.out.print("Enter new name: ");
                        String newName = sc.nextLine();
                        System.out.print("Enter new grade: ");
                        String newGrade = sc.nextLine();
                        sms.editStudent(rollToEdit, newName, newGrade);
                        System.out.println("Student updated.");
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 3:
                    System.out.print("Enter roll number to remove: ");
                    int rollToRemove = getValidInt(sc);
                    sms.removeStudent(rollToRemove);
                    System.out.println("If student existed, they have been removed.");
                    break;

                case 4:
                    System.out.print("Enter roll number to search: ");
                    int rollToSearch = getValidInt(sc);
                    Student found = sms.searchStudent(rollToSearch);
                    if (found != null) {
                        System.out.println("Found: " + found);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    sms.displayAllStudents();
                    break;

                case 6:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 6);

        sc.close();
    }

    public static int getValidInt(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.print("Invalid input. Enter a valid number: ");
            sc.next();
        }
        return sc.nextInt();
    }
}